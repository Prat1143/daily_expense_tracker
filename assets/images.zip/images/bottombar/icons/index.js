/* eslint-disable prettier/prettier */
import MenuIcon from './menu_icon.png';
import MenuActiveIcon from './menu_active_icon.png';
import AccountIcon from './account_icon.png';
import ServicesIcon from './services_icon.png';
import ServicesActiveIcon from './services_active_icon.png';
import CartIcon from './cart_icon.png';
import BottomHomeIcon from './home_icon.png';

export {MenuIcon, AccountIcon, ServicesIcon, CartIcon, BottomHomeIcon, ServicesActiveIcon, MenuActiveIcon};