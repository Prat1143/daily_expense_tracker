/* eslint-disable prettier/prettier */
import bottomBarBg from './bottom_bar_bg.png';

export {bottomBarBg};