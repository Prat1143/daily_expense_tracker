/* eslint-disable prettier/prettier */
import girlNavyPanther from './girl_navy_panther.png';

export {girlNavyPanther};