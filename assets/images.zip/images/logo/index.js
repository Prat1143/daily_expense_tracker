/* eslint-disable prettier/prettier */
import appLogo from './app_logo.png';

export {appLogo};