/* eslint-disable prettier/prettier */
import mumbaiLocationImg from './mumbai_location_img_.png';
import bengaluru from './bengaluru.png';
import chennai from './chennai.png';
import delhi from './delhi.png';
import faridabad from './faridabad.png';
import ghaziabad from './ghaziabad.png';
import gurugram from './gurugram.png';
import hyderabad from './hyderabad.png';
import noida from './noida.png';
import pune from './pune.png';
import blank_location from './blank_location.png';
// import mumbaiLocationImg from './mumbai_location_img.png';

export {mumbaiLocationImg, bengaluru, chennai, delhi, faridabad, ghaziabad, gurugram, hyderabad, noida, pune, blank_location};