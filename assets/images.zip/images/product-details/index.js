/* eslint-disable prettier/prettier */
import productDetailsBannerImage from './banner_image.png';

export {productDetailsBannerImage};