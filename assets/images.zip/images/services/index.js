/* eslint-disable prettier/prettier */
import summersImg from './summers_img.jpg';

export {summersImg};