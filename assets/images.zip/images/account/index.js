/* eslint-disable prettier/prettier */
import profileImg from './profile_img.png';

export {profileImg};