/* eslint-disable prettier/prettier */
import topBarBgImg from './topbar_bg.png';

export {topBarBgImg};