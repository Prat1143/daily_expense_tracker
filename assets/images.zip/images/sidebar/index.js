/* eslint-disable prettier/prettier */
import sidebar_background from './sidebar_background.jpg';

export {sidebar_background};